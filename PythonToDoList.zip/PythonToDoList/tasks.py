import tkinter as tk
from tkinter import messagebox

tasks = []

# Alert popup helper
def alert(message):
    root = tk.Tk()
    root.withdraw()  # Hide main window
    messagebox.showinfo("To Do List Alert", message)
    root.destroy()


def addTask():
    task = input("Please enter a task: ")
    tasks.append(task)
    print(f"Task '{task}' has been added to the to-do list.")


def listTasks():
    if not tasks:
        alert("There are currently no tasks to view.")
        print("There are currently no tasks.")

    else:
        print("Current tasks:")
        for index, task in enumerate(tasks):
            print(f"Task #{index}: {task}")


def removeTask():
    if not tasks:
        alert("No tasks to delete.")
        return
    

    listTasks()
    try:
        deleteTask = int(input("Enter the task number to delete: "))
        if 0 <= deleteTask < len(tasks):
            removed = tasks.pop(deleteTask)
            print(f"Task '{removed}' has been removed.")

        else:
            alert(f"Task #{deleteTask} does not exist.")
            print(f"Task #{deleteTask} was not found.")

    except ValueError:
        alert("Invalid input. Please enter a number.")
        print("Invalid input. Please enter a number.")


if __name__ == "__main__":
    print("Welcome to the To Do List App")

    while True:
        print("\nPlease select an option")
        print("====================")
        print("1. Add a task")
        print("2. Delete a task")
        print("3. List tasks")
        print("4. Exit")
        print("====================")

        choice = input("Enter your choice: ")

        if choice == "1":
            addTask()
        elif choice == "2":
            removeTask()
        elif choice == "3":
            listTasks()
        elif choice == "4":
            break
        else:
            alert("Invalid menu option. Please select 1, 2, 3, or 4.")
            print("Invalid input. Please try again.")

    print("See you later!")

