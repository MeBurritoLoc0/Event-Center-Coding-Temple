README.txt

not much to say about this. The Event Center was just stuff I practiced in my freetime before I took the course and my 'Favorite Website' was just stuff I added
since I already had an interest and some pre-existing knoeledge and experience, and learned some new tricks

I couldn't really think of my 'favorite' website as it were, so I just decided to make a portfolio website instead