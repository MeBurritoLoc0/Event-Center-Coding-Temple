import random

#Base Character class:
class Character:
    def __init__(self, name, health, attack_power):
        self.name = name
        self.health = health
        self.attack_power = attack_power
        self.max_health = health  # Store the original health for maximum limit

    def attack(self, opponent):
        opponent.health -= self.attack_power
        print(f"{self.name} attacks {opponent.name} for {self.attack_power} damage!")
        if opponent.health <= 0:
            print(f"{opponent.name} has been defeated!")

    def display_stats(self):
        print(f"{self.name}'s Stats - Health: {self.health}/{self.max_health}, Attack Power: {self.attack_power}")

    def heal(self):
        self.health += 5
        print(f"{self.name} has healed themselves")
    # Add your heal method here     DONE MAYBE


# Warrior class (inherits from Character)
class Warrior(Character):
    def __init__(self, name):
        super().__init__(name, health=140, attack_power=25)  # Boost health and attack power``

    def special_attack(self, opponent): 
        damage = self.attack_power * 2
        opponent.health -= damage
        print(f"{self.name} has hurt {opponent.name} for {damage} damage")
    # Add your power attack method here DONE


# Mage class (inherits from Character)
class Mage(Character):
    def __init__(self, name):
        super().__init__(name, health=100, attack_power=35)  # Boost attack power

    def special_attack(self, opponent): # Add your cast spell method here
        print("Choose a spell:")
        print("1. Fireball")
        print("2. Ice Blast")
        print("3. Cancel")  # Optional: let player cancel if they change their mind

        spell_choice = input("Enter your spell choice: ")

        if spell_choice == '1':
            self.cast_fireball(opponent)
        elif spell_choice == '2':
            self.cast_ice_blast(opponent)
        elif spell_choice == '3':
            print("You chose not to cast a spell")
        else:
            print("Invalid choice, no spell cast")


    def cast_fireball(self, opponent):
        damage = self.attack_power * 1.5
        opponent.health -= damage
        print(f"{self.name} casts fireball and hurts {opponent.name} for {damage} damage")

    def cast_ice_blast(self, opponent):
        damage = self.attack_power
        opponent.health -= damage
        print(f"{self.name} casts ice blast and hits {opponent.name} for {damage} damage")

        if opponent.health <= 0:
            print(f"{opponent.name} has been defeated!")



# Archer class (inherits from Character)
class Archer(Character):
    def __init__(self, name):
        super().__init__(name, health=80, attack_power=40)  # Boost attack power

    def special_attack(self, opponent): # Add your cast spell method here
        print("Choose a spell:")
        print("1. Volley of Arrows")
        print("2. Healing Salve")
        print("3. Cancel")  # Optional: let player cancel if they change their mind

        spell_choice = input("Choose an attack: ")

        if spell_choice == '1':
            self.volley_of_arrows(opponent)
        elif spell_choice == '2':
            self.healing_salve(opponent)
        elif spell_choice == '3':
            print("You chose not to special attack")
        else:
            print("Invalid choice, no spell cast")


        import random  # Already imported at top

    def volley_of_arrows(self, opponent):
        number_of_arrows = random.randint(2, 4)
        arrow_damage = self.attack_power * 0.5
        crit_chance = 0.2  # 20% crit chance
        crit_multiplier = 2
        total_damage = 0

        print(f"{self.name} fires a Volley of {number_of_arrows} Arrows at {opponent.name}!")

        for i in range(number_of_arrows):
            damage = arrow_damage
            is_crit = False

            if random.random() < crit_chance:
                damage *= crit_multiplier
                is_crit = True

            opponent.health -= damage
            total_damage += damage

            if is_crit:
                print(f"Arrow {i+1} **CRITICAL HIT** for {damage} damage!")
            else:
                print(f"Arrow {i+1} hits for {damage} damage.")

            if opponent.health <= 0:
                print(f"{opponent.name} has been defeated!")
                return  # Stop if opponent defeated

        print(f"Total damage dealt: {total_damage}")


    def healing_salve(self, opponent):
        
        part1 = self.attack_power * 0.75
        opponent.health -= part1

        heal_amount= 10
        self.health += 10
        print(f"{self.name} hits {opponent.name} for {part1} damage and healed for {heal_amount} health")

        # Check for defeat
        if opponent.health <= 0:
            print(f"{opponent.name} has been defeated!")


# Paladin class (inherits from Character)
class Paladin(Character):
    def __init__(self, name):
        super().__init__(name, health=120, attack_power=28)  # Boost attack power

    def special_attack(self, opponent): # Add your cast spell method here
        print("Choose an attack:")
        print("1. Holy Smite")
        print("2. Combo Attack")
        print("3. Cancel")  # Optional: let player cancel if they change their mind

        spell_choice = input("Enter your spell choice: ")

        if spell_choice == '1':
            self.cast_holy_smite(opponent)
        elif spell_choice == '2':
            self.cast_combo_attack(opponent)
        elif spell_choice == '3':
            print("You chose not to cast a spell")
        else:
            print("Invalid choice, no spell cast")


    def cast_holy_smite(self, opponent):
        damage = self.attack_power * 1.5
        opponent.health -= damage
        print(f"{self.name} casts holy smite and smites {opponent.name} for {damage} damage")

    def cast_combo_attack(self, opponent):
        
        hit1 = self.attack_power * 0.75
        opponent.health -= hit1
        print(f"First hit deals {hit1} damage!")

        hit2 = self.attack_power * 0.75
        opponent.health -= hit2
        print(f"Second hit deals {hit2} damage!")

        # Check for defeat
        if opponent.health <= 0:
            print(f"{opponent.name} has been defeated!")

# EvilWizard class (inherits from Character)
class EvilWizard(Character):
    def __init__(self, name):
        super().__init__(name, health=150, attack_power=15)  # Lower attack power
    
    # Evil Wizard's special ability: it can regenerate health
    def regenerate(self):
        self.health += 5  # Lower regeneration amount
        print(f"{self.name} regenerates 5 health! Current health: {self.health}")

# Function to create player character based on user input
def create_character():
    print("Choose your character class:")
    print("1. Warrior")
    print("2. Mage")
    print("3. Archer")  # Add Archer
    print("4. Paladin")  # Add Paladin
    
    class_choice = input("Enter the number of your class choice: ")
    name = input("Enter your character's name: ")

    if class_choice == '1':
        return Warrior(name)
    elif class_choice == '2':
        return Mage(name)
    elif class_choice == '3':
        return Archer(name) # Add Archer class here
        pass
    elif class_choice == '4':
        return Paladin(name) # Add Paladin class here
        pass
    else:
        print("Invalid choice. Defaulting to Warrior.")
        return Warrior(name)

# Battle function with user menu for actions
def battle(player, wizard):
    while wizard.health > 0 and player.health > 0:
        print("\n--- Your Turn ---")
        print("1. Attack")
        print("2. Use Special Ability")
        print("3. Heal")
        print("4. View Stats")
        
        choice = input("Choose an action: ")

        if choice == '1':
            player.attack(wizard)
        elif choice == '2':
            player.special_attack(wizard) # Call the special ability here CHECK THIS
            pass  # Implement this
        elif choice == '3':
            player.heal() # Call the heal method here
            pass  # Implement this
        elif choice == '4':
            player.display_stats()
        else:
            print("Invalid choice, try again.")
            continue

        # Evil Wizard's turn to attack and regenerate
        if wizard.health > 0:
            wizard.regenerate()
            wizard.attack(player)

        if player.health <= 0:
            print(f"{player.name} has been defeated!")
            break

    if wizard.health <= 0:
        print(f"The wizard {wizard.name} has been defeated by {player.name}!")

# Main function to handle the flow of the game
def main():
    # Character creation phase
    player = create_character()

    # Evil Wizard is created
    wizard = EvilWizard("The Dark Wizard")

    # Start the battle
    battle(player, wizard)

if __name__ == "__main__":
    main()