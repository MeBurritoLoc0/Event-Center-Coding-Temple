import React from "react";
import "./Search.css";
const Search =({ value, onChangeData}) => {
    return (
        <div>
            <input 
                className="search-input"
                type="text"
                placeholder="Search for product"
                value={value}
                onChange={onChangeData}
            />
        </div>
    );
};

export default Search;