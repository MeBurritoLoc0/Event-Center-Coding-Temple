import React, { useEffect, useState } from "react";
import Header from "./components/header/Header"; 
import Search from "./components/search/Search"; 
import AddProducts from "./components/addproducts/AddProducts"; 
import CardBody from "./components/cards/CardBody"; 
import Button from "./components/button/Button";

import "./App.css";


const App = () => {
  const [items, setItems] = useState([]); 

  const [searchValue, setSearchValue] = useState(""); 

  const [addedItems, setAddedItems] = useState([]); 

  const [showAddProducts, setShowAddProducts] = useState(false);


  useEffect(() => { fetch("https://fakestoreapi.com/products/").then((res) => res.json()).then(setItems); console.count("Data fetched:"); }, []);

  const handleSearchChange = (e) => { setSearchValue(e.target.value); };

  const itemsFiltered = items.filter((item) => item.title.toLowerCase().includes(searchValue.toLowerCase()));

  const addItem = (item) => { item.addNumber = 1; setAddedItems((prev) => [...prev, item]); };

  const removeItem = (item) => { setAddedItems((prev) => prev.filter((i) => i.id !== item.id)); };


  return (
    <div className="body_container">
      <div className="nav"> 
        <Header /> <div className="nav-right"> 
          <Search products={items} value={searchValue} onChangeData={handleSearchChange} /> 
          <Button num={addedItems.length} click={setShowAddProducts} /> </div> </div>

      {showAddProducts && <AddProducts click={setShowAddProducts} items={addedItems} removeItem={removeItem} setAddedItem={setAddedItems} />}

      <CardBody products={itemsFiltered} addItem={addItem} removeItem={removeItem} addedItems={addedItems} />
    </div>
  );
};


export default App;